import express from "express";
import {
    getUsers, 
    getUserById,
    createUser,
    updateUser,
    deleteUser
} from "../controllers/UserController.js";

const router = express.Router();

router.get('/tlog', getUsers);
router.get('/tlog/:id', getUserById);
router.post('/tlog', createUser);
router.patch('/tlog/:id', updateUser);
router.delete('/tlog/:id', deleteUser);

export default router;